# IF.03.01-11 Basic Web Techniques - Dynamic Css 3 Features
This coding assignment shall make you practice the dynamic css3 features. Make sure that you read the section *Required Tasks*  in [CodingAssignment.md](CodingAssignment.md) carefully and to complete all the tasks listed there.
